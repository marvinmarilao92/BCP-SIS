<?php
    $conn = mysqli_connect("31.220.110.2", "u692894633_sis_cluster6a", "?kZ]!w7?k+1", "u692894633_SIS_C6A");
?>
